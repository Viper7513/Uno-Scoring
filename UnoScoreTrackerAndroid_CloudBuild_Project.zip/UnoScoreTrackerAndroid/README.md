# UNO Score Tracker Android Project

This is a simple Android WebView wrapper for the UNO Score Tracker.

## Included
- Dark theme throughout.
- Maximum of 6 players.
- Player selection before starting.
- Round winner selection.
- UNO-style graphical card picker.
- Shuffle Hands card added at 50 points.
- Standard scoring rules.
- Local score saving through WebView local storage.
- Game completion when a player exceeds 500 points.

## Build the APK in Android Studio
1. Open Android Studio.
2. Select **Open**.
3. Choose the `UnoScoreTrackerAndroid` folder.
4. Let Android Studio sync Gradle.
5. Select **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
6. Use the **locate** link when the build finishes to find the APK.

The app works offline because it loads `app/src/main/assets/uno_score_tracker.html`.


## Phone-only cloud APK build using GitHub Actions

This project now includes `.github/workflows/build-apk.yml`.

1. Create a new GitHub repository.
2. Upload the contents of this folder to the repository.
3. Open the repository on GitHub.
4. Go to **Actions**.
5. Select **Build UNO Score Tracker APK**.
6. Tap **Run workflow**.
7. When the build finishes, open the completed run.
8. Download the artifact called **UNO-Score-Tracker-debug-apk**.
9. Extract it and install `app-debug.apk` on your Android phone.

Android may ask you to allow installs from your browser or file manager. That is normal for an APK installed outside Google Play.
